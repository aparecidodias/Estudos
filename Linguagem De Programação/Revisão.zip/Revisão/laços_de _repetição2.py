frutas = ["maça", "banana", "uva"]

for fruta in frutas:
    print(fruta)