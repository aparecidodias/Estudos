def saudacao():
    print("Bem - vindo!")
    #chamando
    
saudacao()

    #Função com parâmetros

def soma (a , b):
    return a + b

resultado = soma(5, 3)
print(resultado)
