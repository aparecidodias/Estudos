#armazena valores por chave
aluno = {
"nome": "Pedro",
"Idade":17,
"nota": 9.0
}

print(aluno["nome"])

#Altera Valores
aluno["nota"] = 9.5

#adicionando nova chave
aluno["turma"] = "3A"
print(aluno)