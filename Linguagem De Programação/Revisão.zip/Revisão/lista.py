frutas = ["maça", "banana", "mamão"]

#Acessando
print(frutas[0])   #maça

#adicionando
frutas.append("uva")#aa

#Removendo
frutas.remove("banana")


#alterando
frutas[1]= "Abacaxi"
print(frutas)


