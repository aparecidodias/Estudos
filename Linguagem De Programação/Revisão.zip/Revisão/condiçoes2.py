idade = 18
tem_carteira = True

if idade >= 18 and tem_carteira:
    print("Pode dirigir. ")