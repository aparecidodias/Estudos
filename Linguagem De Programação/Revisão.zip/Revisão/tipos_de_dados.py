idade = 26  #int
altura = 1.75 #floot
nome = "Bruno" # str
maior =True  #boot
